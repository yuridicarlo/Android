package it.bancomat.pay.consumer.init.model;

public enum ErrorState {

    RETRY_BIOMETRIC_ENROLL, RETRY_STORE_BIOMETRIC_ENROLL_DATA, RETRY_INIT_SDK
}
