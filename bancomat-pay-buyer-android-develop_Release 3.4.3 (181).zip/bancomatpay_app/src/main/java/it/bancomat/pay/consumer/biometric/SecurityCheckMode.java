package it.bancomat.pay.consumer.biometric;

public enum SecurityCheckMode {
	DEVICE_SECURED_ONLY, ROOT_ONLY, FULL_CHECK
}
