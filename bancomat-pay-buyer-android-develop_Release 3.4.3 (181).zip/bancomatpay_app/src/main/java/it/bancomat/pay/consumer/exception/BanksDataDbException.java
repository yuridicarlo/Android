package it.bancomat.pay.consumer.exception;

public class BanksDataDbException extends Exception {

    public BanksDataDbException(String message) {
        super(message);
    }

}
