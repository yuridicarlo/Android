package it.bancomat.pay.consumer.events;

public class ForceReopenBancomatFlow {

}
