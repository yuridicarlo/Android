package it.bancomat.pay.consumer.init;

import android.os.Bundle;

import it.bancomatpay.consumer.R;

public class InitActivity extends BaseInitActivity {


    @Override
    int getContentView() {
        return R.layout.activity_init;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
