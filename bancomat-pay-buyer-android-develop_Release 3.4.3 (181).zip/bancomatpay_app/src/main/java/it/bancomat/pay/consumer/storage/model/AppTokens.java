package it.bancomat.pay.consumer.storage.model;

public class AppTokens {

    private String oauth;
    private String refres;

    public String getOauth() {
        return oauth;
    }

    public void setOauth(String oauth) {
        this.oauth = oauth;
    }

    public String getRefres() {
        return refres;
    }

    public void setRefres(String refres) {
        this.refres = refres;
    }

}
