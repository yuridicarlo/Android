package it.bancomatpay.sdk.manager.model;

public enum AuthenticationOperationType {

    PAYMENT, BANKID, ATM, BPLAY, DIRECT_DEBITS, CASHBACK, POS

}
