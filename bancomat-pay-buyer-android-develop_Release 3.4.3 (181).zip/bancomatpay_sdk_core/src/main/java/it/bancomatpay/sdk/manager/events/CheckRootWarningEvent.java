package it.bancomatpay.sdk.manager.events;

public class CheckRootWarningEvent {

}
