package it.bancomatpay.sdk.manager.events.request;

public class BankServicesUpdateEvent {

}
